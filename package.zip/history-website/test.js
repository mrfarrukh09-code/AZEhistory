const { chromium } = require('playwright');
const path = require('path');

(async () => {
    const browser = await chromium.launch();
    const page = await browser.newPage();

    const errors = [];
    page.on('pageerror', error => {
        errors.push(error.message);
    });

    page.on('console', msg => {
        if (msg.type() === 'error') {
            errors.push(msg.text());
        }
    });

    const filePath = 'file://' + path.resolve(__dirname, 'index.html');
    await page.goto(filePath);

    // Wait for page to load
    await page.waitForTimeout(2000);

    // Check page title
    const title = await page.title();
    console.log('Page title:', title);

    // Check if main sections exist
    const heroExists = await page.$('.hero') !== null;
    const timelineExists = await page.$('.timeline') !== null;
    const galleryExists = await page.$('.gallery-grid') !== null;
    const footerExists = await page.$('footer') !== null;

    console.log('Hero section:', heroExists ? 'OK' : 'MISSING');
    console.log('Timeline section:', timelineExists ? 'OK' : 'MISSING');
    console.log('Gallery section:', galleryExists ? 'OK' : 'MISSING');
    console.log('Footer:', footerExists ? 'OK' : 'MISSING');

    if (errors.length > 0) {
        console.log('\nConsole Errors:');
        errors.forEach(e => console.log(' -', e));
    } else {
        console.log('\nNo console errors detected!');
    }

    await browser.close();

    process.exit(errors.length > 0 ? 1 : 0);
})();
