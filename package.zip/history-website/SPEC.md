# Tarix Saytı - Specification v2

## 1. Concept & Vision

Azərbaycan tarixinə həsr olunmuş immersive və interaktiv veb sayt. Sayt antik və müasir arasında körpü rolunu oynayır - qədim kağız teksturası və klassik tipoqrafiya ilə müasir animasiyaların harmoniyası. İstifadəçi öz tarixi səyahətinə çıxır, dövrləri kəşf edir və hər dövrə click edərək dərin məlumat əldə edir.

## 2. Design Language

### Aesthetic Direction
Antik kitabxana + müasir museum hybrid - qədim xəritələrin estetikası, parşomen teksturası, lakin clean modern layout ilə.

### Color Palette
- **Primary**: `#8B4513` (Saddle Brown - antik qəhvə)
- **Secondary**: `#D4A574` (Antik qızıl)
- **Accent**: `#C41E3A` (Kardinal qırmızı - diqqət çəkən elementlər)
- **Background**: `#FDF5E6` (Old Lace - parşomen)
- **Dark Background**: `#2C1810` (Qaranlıq qəhvə)
- **Text**: `#3D2914` (Qəhvəyi text)
- **Light Text**: `#F5E6D3` (Açıq tekst)

### Typography
- **Headings**: "Playfair Display" - klassik, zərif serif
- **Body**: "Crimson Text" - oxunaqlı, tarixi his
- **Accents**: "Cinzel" - başlıqlar üçün monumental görünüş

## 3. Layout & Structure

### Hero Section
- Full viewport height
- Large decorative title with text-shadow
- Animated compass SVG decoration
- Scroll indicator with bounce animation

### Timeline Section
- Vertical timeline with alternating left/right cards
- Each era: clickable with detailed information modal
- Connection line with glowing effect
- Era icons as visual markers

### Interactive Era Cards (EXPANDABLE)
- 4 main historical periods as expandable cards
- Click to expand and show detailed information
- NO images - text-only detailed content
- Smooth expand/collapse animation
- Each era contains:
  - Overview paragraph
  - Key facts (bullet points)
  - Important figures
  - Major events
  - Cultural achievements

### Modal for Detailed View
- Full-screen overlay on click
- Scrollable content
- Close button
- Structured information sections

### Quote Section
- Historical quote display

### Footer
- Decorative border
- Social links
- Navigation links

## 4. Features & Interactions

### Core Features
- **Smooth scrolling navigation**: Click nav links smooth scroll to sections
- **Interactive timeline**: Visual representation of historical periods
- **Expandable era cards**: Click to reveal detailed information (NO images)
- **Detailed modal view**: Full information display when clicking timeline items
- **Responsive design**: Works on all devices

### Interaction Details
- Era cards: Click expands with smooth animation, shows detailed text
- Timeline dots: Click opens modal with full era information
- Cards: Visual feedback on hover
- Modal: Fade in with backdrop blur

## 5. Component Inventory

### Navigation Bar
- Fixed position, transparent → solid on scroll
- Logo + nav links
- Mobile hamburger menu

### Hero Title
- Large decorative heading
- Subtitle with fade-in delay

### Timeline Item (Clickable)
- Era icon, date badge
- Title and preview description
- Click opens detailed modal
- States: default, hover, active

### Era Card (Expandable)
- Header with icon and title
- Preview content visible
- "Daha ətraflı" button to expand
- Expanded: Full detailed text content
- NO images in expanded content

### Detailed Modal
- Full-screen overlay
- Structured sections with headings
- Scrollable content area
- Close button (X)
- Keyboard navigation (ESC to close)

## 6. Technical Approach

- **Framework**: Vanilla HTML5, CSS3, JavaScript
- **Animations**: CSS transitions + Intersection Observer API
- **Icons**: Custom SVG inline
- **Fonts**: Google Fonts (Playfair Display, Crimson Text, Cinzel)
- **No external images in era content**
- **Build**: No build step required, deploy directly
